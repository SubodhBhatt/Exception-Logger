Time::DATE_FORMATS.merge!(
  :exc_full => "%A, %b %d, %Y at %l:%M %p",
  :exc_date => "%b %d, %Y",
  :exc_time => "%l:%M %p"
)
