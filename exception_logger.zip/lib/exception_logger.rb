module ExceptionLogger
  require 'exception_logger/engine' 
  require 'exception_logger/exception_loggable'  
end